# Visibility Aware UV Optimizer 0.5.4

Blender 3.3 through 5.2 add-on for visibility analysis and conservative UV
generation. Version 0.5.4 adds a hard-surface workflow for game weapons and
props while retaining the 0.5.3 Legacy Smart mode.

## Install

Install the release ZIP through `Edit > Preferences > Add-ons > Install`, then
enable `Visibility Aware UV Optimizer`. The panel is in
`View3D > Sidebar > UV Optimizer`.

The optimizer operates on the active mesh object. Duplicate production assets
or keep a source-control copy before replacing an approved UV layout.

## Recommended hard-surface workflow

1. Apply or verify object scale and clean zero-area faces, duplicate vertices,
   non-manifold edges, and invalid n-gons.
2. Mark artist seams in Edit Mode with `Edge > Mark Seam` where a continuous
   texture must stop.
3. Set `Initial UV Mode` to `Auto`, `UV Usage` to `Auto`, and use the
   `Weapon / Prop` profile.
4. Keep `Preserve Existing Seams`, `Respect Material Borders`, and
   `Align Long Islands` enabled.
5. Keep `Cut Sharp Edges` disabled for imported production assets unless Sharp
   edges were deliberately authored as UV cuts.
6. Run `Optimize Active Object UV`. A Unique result is committed only when the
   final quality gate passes.

Recommended 0.5.4 starting values are:

| Setting | Value |
| --- | ---: |
| Auto Hard Edge Angle | 70 degrees |
| Panel Flatness | 5 degrees |
| Initial Angle | 70 degrees |
| Merge Search Angle | 130 degrees |
| P95 Stretch | 1.50 |
| Max Stretch | 3.0 |
| Merge Tests | 500 |
| Small Island Faces | 12 |
| Small Island Area | 0.004 |
| Developable Angle | 55 degrees |
| Band Merge Bonus | 0.40 |
| Island Margin | 0.002 |

## UV contracts

`UV Usage: Auto` infers the contract from underscore-delimited object-name
tokens:

| Contract | Recognized name token | Auto behavior |
| --- | --- | --- |
| Unique / Bake | default | Generate, pack to 0-1, and run the strict gate |
| Trim Sheet | `TrimSheet` or `Trim_Sheet` | Preserve the existing layout |
| Info Atlas | `InfoAtlas` or `Info_Atlas` | Preserve the existing layout |
| LED / VFX | `LED`, `LED1`, `VFX`, or `VFX1` | Preserve the existing layout |

Auto preservation applies only when `Initial UV Mode` is also `Auto`.
Selecting `Hard Surface`, `Marked Seams`, or `Legacy Smart` explicitly requests
a rebuild and can reproject or pack a non-Unique layout.

## Hard-surface boundary rules

The seed pass classifies panels, bevel bands, cylinder sides, radial caps, and
general geometry. Boundaries are prioritized as follows:

- Mesh boundaries and non-manifold edges are structural cuts.
- Preserved artist seams are locked and never merged.
- Material borders are cuts when `Respect Material Borders` is enabled.
- Cylinder cap boundaries and one stable longitudinal cylinder opening are
  cuts. A regular capped cylinder is expected to produce one side island and
  two cap islands.
- Explicit Sharp edges are cuts only when `Cut Sharp Edges` is enabled. It is
  disabled by default because production shading data is often much denser
  than the intended UV seam set.
- Geometric hard angles, bevels, concave edges, visibility, and developable
  bands influence merge preference but still pass topology, stretch, winding,
  and overlap checks.

`Panel Flatness` controls whether a grown region is treated as a planar panel.
Long accepted islands are aligned to a horizontal or vertical axis when
`Align Long Islands` is enabled.

## Unique quality gate

Unique / Bake output must satisfy every final condition:

- all UV coordinates are finite and inside the 0-1 tile;
- source triangles and UV triangles are non-degenerate;
- every triangle has consistent positive winding;
- no positive-area overlap exists within an island or between islands;
- every real UV discontinuity has a matching seam flag.

Blender's pack operator is run with all UVs explicitly selected and the active
UDIM target. If the concave pack still overlaps, an AABB safety pack is tried.
Any remaining failure cancels the operation and restores all UV layers,
coordinates, pin/selection data, active/render layer identity, seam flags,
mesh selection, hidden state, and the prior `vuv_detail_score` attribute.

The final Unique gate remains strict even if `Reject UV Overlap` is disabled;
that setting controls candidate merge rejection, not the final contract.

Meshes containing zero-area faces, collapsed triangles, duplicate surfaces,
or severe non-manifold topology may be rejected. Clean the source geometry
instead of loosening the final gate.

## Multiple UV layers and non-Unique layouts

Rebuild modes rewrite only the active UV map. Other UV layers and the
active/render layer identities are preserved. Auto Preserve Layout keeps the
active UV coordinates and seam flags byte-for-byte stable, including deliberate
stacking and coordinates outside 0-1; it may refresh the non-UV
`vuv_detail_score` analysis attribute.

`Collapse Hidden Overrides` is disabled by default. Keep it disabled for a
Unique contract because collapsed textured faces are intentionally degenerate.
Use it only for an explicitly rebuilt non-Unique layout where shared hidden
coverage is acceptable.

## Visibility and mapping viewer

The add-on also provides six-camera, selected-camera, hybrid, sphere-sampling,
and exterior-flood visibility analysis. Face priorities are stored as mesh
attributes and can be overridden as Important, Hidden, or Auto.

`Interactive Mapping > Export Viewer` writes a standalone HTML file containing
the selected mesh and UV data. Click a UV face or island to locate its 3D
surface; repeated clicks cycle overlapping faces. The viewer has no external
web dependency.

## Validation scope

The 0.5.4 release is tested in Blender 3.3.5 and Blender 5.2.0. Synthetic tests
cover marked/material/Sharp cuts, a capped cylinder, a long rail, hidden
geometry, multiple UV layers, non-Unique preservation, operator RNA differences,
selection state, rollback, and injected overlap/winding/degeneracy failures.

On the supplied Blender 5.2 weapon scene, `SM_CDO_ChopSword_1_LOD1` passes the
Unique gate with 220 islands and 4,246 positive triangles. Four other sampled
Unique assets are rejected because their source geometry or projected charts
remain degenerate; their original state is restored. A rejection is an expected
safe result, not a successful UV rebuild.
