# SPDX-License-Identifier: GPL-2.0-or-later

import math
from collections import defaultdict
from dataclasses import dataclass

import bmesh
import bpy
from mathutils import Vector
from mathutils.geometry import tessellate_polygon

from . import probe_analysis
from . import hard_surface
from .visibility import effective_face_visibility
from .visibility import read_face_int
from .visibility import write_face_float


_LOW_VISIBILITY_SCALE = 0.01
_UV_SELECTION_ATTRIBUTES = (
    '.uv_select_vert',
    '.uv_select_edge',
    '.uv_select_face',
)


def _snapshot_face_float_attribute(mesh, name):
    attributes = getattr(mesh, 'attributes', None)
    if attributes is None:
        return None
    attribute = attributes.get(name)
    if (
            attribute is None
            or getattr(attribute, 'data_type', None) != 'FLOAT'
            or str(getattr(attribute, 'domain', '')) != 'FACE'):
        return None
    return [float(item.value) for item in attribute.data]


def _restore_face_float_attribute(mesh, name, values):
    attributes = getattr(mesh, 'attributes', None)
    if attributes is None:
        return
    attribute = attributes.get(name)
    if values is None:
        if attribute is not None:
            try:
                attributes.remove(attribute)
            except (ReferenceError, RuntimeError):
                pass
        return
    if (
            attribute is None
            or getattr(attribute, 'data_type', None) != 'FLOAT'
            or str(getattr(attribute, 'domain', '')) != 'FACE'):
        if attribute is not None:
            try:
                attributes.remove(attribute)
            except (ReferenceError, RuntimeError):
                attribute = None
        try:
            attribute = attributes.new(
                name=name, type='FLOAT', domain='FACE')
        except (RuntimeError, TypeError, ValueError):
            attribute = attributes.get(name)
    if attribute is None or len(attribute.data) != len(values):
        return
    for item, value in zip(attribute.data, values):
        item.value = float(value)


def _snapshot_uv_selection_attributes(mesh):
    attributes = getattr(mesh, 'attributes', None)
    if attributes is None:
        return {}
    result = {}
    for name in _UV_SELECTION_ATTRIBUTES:
        attribute = attributes.get(name)
        if attribute is None or getattr(attribute, 'data_type', None) != 'BOOLEAN':
            result[name] = None
            continue
        result[name] = {
            'domain': str(attribute.domain),
            'values': [bool(item.value) for item in attribute.data],
        }
    return result


def _restore_uv_selection_attributes(mesh, states):
    attributes = getattr(mesh, 'attributes', None)
    if attributes is None:
        return
    for name, state in (states or {}).items():
        attribute = attributes.get(name)
        if state is None:
            if attribute is not None:
                try:
                    attributes.remove(attribute)
                except (ReferenceError, RuntimeError):
                    pass
            continue
        domain = state.get('domain', 'CORNER')
        if (
                attribute is None
                or getattr(attribute, 'data_type', None) != 'BOOLEAN'
                or str(getattr(attribute, 'domain', '')) != domain):
            if attribute is not None:
                try:
                    attributes.remove(attribute)
                except (ReferenceError, RuntimeError):
                    attribute = None
            try:
                attribute = attributes.new(
                    name=name, type='BOOLEAN', domain=domain)
            except (RuntimeError, TypeError, ValueError):
                attribute = attributes.get(name)
        values = state.get('values', ())
        if attribute is None or len(attribute.data) != len(values):
            continue
        for item, value in zip(attribute.data, values):
            item.value = bool(value)


def _filter_operator_kwargs(operator, kwargs, operator_name=None):
    """Return kwargs shared by the installed Blender operator RNA.

    Blender 3.3 and 5.2 expose different optional UV operator properties.  The
    RNA probe keeps the shared code path conservative and is also useful to
    callers that need to report which options were accepted.
    """
    try:
        properties = operator.get_rna_type().properties
        supported = {item.identifier for item in properties}
    except (AttributeError, RuntimeError, TypeError):
        if operator_name and tuple(bpy.app.version) < (4, 0, 0):
            blender_33 = {
                'smart_project': {
                    'angle_limit', 'island_margin', 'area_weight',
                    'correct_aspect', 'scale_to_bounds',
                },
                'unwrap': {
                    'method', 'fill_holes', 'correct_aspect',
                    'use_subsurf_data', 'margin',
                },
                'average_islands_scale': {'scale_uv', 'shear'},
                'pack_islands': {'udim_source', 'rotate', 'margin'},
            }
            supported = blender_33.get(operator_name)
            if supported is not None:
                return {
                    key: value for key, value in kwargs.items()
                    if key in supported
                }
        return dict(kwargs)
    return {key: value for key, value in kwargs.items() if key in supported}


def _call_uv_operator(operator, _operator_name=None, **kwargs):
    return operator(**_filter_operator_kwargs(
        operator, kwargs, operator_name=_operator_name))


def _resolve_uv_usage(obj, settings):
    value = getattr(settings, "uv_usage", 'AUTO')
    if value != 'AUTO':
        return value
    name = (getattr(obj, "name", "") or "").upper()
    if 'TRIMSHEET' in name or 'TRIM_SHEET' in name:
        return 'TRIM_SHEET'
    if 'INFOATLAS' in name or 'INFO_ATLAS' in name:
        return 'INFO_ATLAS'
    tokens = [token for token in name.split('_') if token]
    if any(
            token in {'LED', 'VFX'}
            or (token.startswith('LED') and token[3:].isdigit())
            or (token.startswith('VFX') and token[3:].isdigit())
            for token in tokens):
        return 'LED'
    return 'UNIQUE'


def _resolve_initial_uv_mode(settings, original_seams, uv_usage='UNIQUE'):
    value = getattr(settings, "initial_uv_mode", 'LEGACY_SMART')
    if value != 'AUTO':
        return value
    # Non-unique texture contracts commonly contain deliberate stacking and
    # carefully placed atlas coordinates.  Re-projecting or packing them is
    # destructive, so Auto is a true no-op for these layouts.  Users can still
    # select Hard Surface or Legacy Smart explicitly when a rebuild is wanted.
    if uv_usage != 'UNIQUE':
        return 'PRESERVE_LAYOUT'
    return 'MARKED_SEAMS' if original_seams else 'HARD_SURFACE'


def _inspect_existing_layout(mesh):
    """Return island/detail data without changing the mesh or its UV layers."""
    active_layer = mesh.uv_layers.active
    if active_layer is None or len(active_layer.data) != len(mesh.loops):
        raise ValueError(
            "Preserve Layout needs a valid active UV map; choose an explicit "
            "rebuild mode to create one"
        )
    bm = bmesh.new()
    try:
        bm.from_mesh(mesh)
        bm.faces.index_update()
        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.get(active_layer.name)
        if uv_layer is None:
            raise ValueError("Active UV map is unavailable in BMesh")
        # Derive chart boundaries only on this detached BMesh.  Existing Mesh
        # seam flags and every UV coordinate remain untouched.
        _derive_seams_from_uv(bm, uv_layer, set())
        _, charts = _charts(bm)
        return len(charts), _compute_face_detail(bm)
    finally:
        bm.free()


def _snapshot_mesh_uv_state(mesh):
    """Capture UV layers and seam flags without assuming every layer is valid."""
    layers = []
    loop_count = len(mesh.loops)
    for layer in mesh.uv_layers:
        try:
            if len(layer.data) != loop_count:
                continue
            layers.append((layer.name, [
                {
                    'uv': item.uv.copy(),
                    'select': bool(getattr(item, 'select', False)),
                    'select_edge': bool(getattr(item, 'select_edge', False)),
                    'pin_uv': bool(getattr(item, 'pin_uv', False)),
                }
                for item in layer.data
            ]))
        except (IndexError, ReferenceError, RuntimeError):
            continue
    active_layer = mesh.uv_layers.active if mesh.uv_layers.active else None
    try:
        render_layer = mesh.uv_layers.active_render
    except AttributeError:
        # Blender 3.3 has no active_render accessor on UV layers; the active
        # layer is the only stable layer identity available there.
        render_layer = active_layer
    return {
        'layers': layers,
        'layer_names': [name for name, _ in layers],
        'active_index': int(getattr(mesh.uv_layers, 'active_index', -1)),
        'active': active_layer.name if active_layer else None,
        'render': render_layer.name if render_layer else None,
        'seams': [bool(edge.use_seam) for edge in mesh.edges],
        'vertex_selection': [bool(vertex.select) for vertex in mesh.vertices],
        'edge_selection': [bool(edge.select) for edge in mesh.edges],
        'face_selection': [bool(face.select) for face in mesh.polygons],
        'vertex_hidden': [bool(vertex.hide) for vertex in mesh.vertices],
        'edge_hidden': [bool(edge.hide) for edge in mesh.edges],
        'face_hidden': [bool(face.hide) for face in mesh.polygons],
        'uv_selection_attributes': _snapshot_uv_selection_attributes(mesh),
        'detail_score': _snapshot_face_float_attribute(
            mesh, 'vuv_detail_score'),
        'active_face': int(getattr(mesh.polygons, 'active', -1)),
    }


def _restore_mesh_interaction_state(mesh, snapshot):
    for name, values in snapshot.get('layers', ()):
        layer = mesh.uv_layers.get(name)
        if layer is None or len(layer.data) != len(values):
            continue
        for item, state in zip(layer.data, values):
            for key in ('select', 'select_edge', 'pin_uv'):
                if hasattr(item, key):
                    setattr(item, key, bool(state.get(key, False)))
    for vertex, state in zip(
            mesh.vertices, snapshot.get('vertex_selection', ())):
        vertex.select = bool(state)
    for edge, state in zip(
            mesh.edges, snapshot.get('edge_selection', ())):
        edge.select = bool(state)
    for face, state in zip(
            mesh.polygons, snapshot.get('face_selection', ())):
        face.select = bool(state)
    for vertex, state in zip(
            mesh.vertices, snapshot.get('vertex_hidden', ())):
        vertex.hide = bool(state)
    for edge, state in zip(
            mesh.edges, snapshot.get('edge_hidden', ())):
        edge.hide = bool(state)
    for face, state in zip(
            mesh.polygons, snapshot.get('face_hidden', ())):
        face.hide = bool(state)
    active_face = int(snapshot.get('active_face', -1))
    if hasattr(mesh.polygons, 'active'):
        try:
            mesh.polygons.active = active_face
        except (AttributeError, RuntimeError, TypeError, ValueError):
            pass
    _restore_uv_selection_attributes(
        mesh, snapshot.get('uv_selection_attributes', {}))
    mesh.update()


def _restore_mesh_uv_state(mesh, snapshot):
    if not snapshot:
        return
    original_names = set(snapshot.get('layer_names', ()))
    # Failed Smart/Unwrap calls may have created a UV layer on an object that
    # started without one.  Remove only layers introduced after the snapshot.
    for layer in list(mesh.uv_layers):
        if layer.name not in original_names:
            try:
                mesh.uv_layers.remove(layer)
            except (ReferenceError, RuntimeError):
                pass
    for name, values in snapshot.get('layers', ()):
        layer = mesh.uv_layers.get(name)
        if layer is None or len(layer.data) != len(values):
            continue
        for item, state in zip(layer.data, values):
            item.uv = state['uv']
            for key in ('select', 'select_edge', 'pin_uv'):
                if hasattr(item, key):
                    setattr(item, key, bool(state.get(key, False)))
    for edge, state in zip(mesh.edges, snapshot.get('seams', ())):
        edge.use_seam = bool(state)
    _restore_face_float_attribute(
        mesh, 'vuv_detail_score', snapshot.get('detail_score'))
    _restore_mesh_interaction_state(mesh, snapshot)
    active = snapshot.get('active')
    render = snapshot.get('render')
    if active and mesh.uv_layers.get(active):
        mesh.uv_layers.active = mesh.uv_layers.get(active)
    active_index = int(snapshot.get('active_index', -1))
    if 0 <= active_index < len(mesh.uv_layers):
        mesh.uv_layers.active_index = active_index
    if render and mesh.uv_layers.get(render):
        try:
            mesh.uv_layers.active_render = mesh.uv_layers.get(render)
        except AttributeError:
            pass
    mesh.update()


@dataclass
class OptimizeResult:
    initial_islands: int
    final_islands: int
    merge_tests: int
    accepted_merges: int
    rejected_stretch: int
    rejected_overlap: int
    rejected_topology: int
    detail_values: list
    rejected_probe: int = 0
    probe_guided_merges: int = 0
    initial_uv_mode: str = 'LEGACY_SMART'
    uv_usage: str = 'UNIQUE'
    forced_cuts: int = 0
    protected_cuts: int = 0
    repaired_charts: int = 0
    mirrored_charts: int = 0
    safe_pack_retry: bool = False


def _set_uv_selection(bm, uv_layer, selected_faces):
    selected = set(selected_faces)
    for vertex in bm.verts:
        vertex.select_set(False)
    for edge in bm.edges:
        edge.select_set(False)
    for face in bm.faces:
        state = face.index in selected
        face.select_set(state)
        if state:
            for vertex in face.verts:
                vertex.select_set(True)
            for edge in face.edges:
                edge.select_set(True)
        for loop in face.loops:
            if hasattr(loop, "uv_select_vert_set") and hasattr(loop, "uv_select_edge_set"):
                loop.uv_select_vert_set(state)
                loop.uv_select_edge_set(state)
            else:
                loop[uv_layer].select = state
                loop[uv_layer].select_edge = state
    if hasattr(bm, "uv_select_flush_mode"):
        bm.uv_select_flush_mode()


def _select_all_uvs_for_operator(mesh, bm, uv_layer):
    """Synchronize whole-layout selection before a global UV operator.

    In Blender 5.x, setting every BMLoop UV selection flag is not sufficient
    in every UV selection mode.  Pack Islands can report FINISHED while leaving
    some islands untouched.  Running the UV selection operator after flushing
    the BMesh state makes the intended whole-layout scope explicit in both 3.3
    and 5.x.  The public optimizer isolates one active mesh before entering
    Edit Mode; callers using this helper directly must provide the same scope.
    """
    _set_uv_selection(bm, uv_layer, (face.index for face in bm.faces))
    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
    result = bpy.ops.uv.select_all(action='SELECT')
    if 'FINISHED' not in result:
        raise RuntimeError("Select All UVs did not finish")
    return _refresh_edit_bmesh(mesh)


def _refresh_edit_bmesh(mesh):
    """Return current edit BMesh handles after a UV operator call."""
    bm = bmesh.from_edit_mesh(mesh)
    bm.faces.index_update()
    bm.faces.ensure_lookup_table()
    bm.edges.ensure_lookup_table()
    bm.verts.ensure_lookup_table()
    return bm, bm.loops.layers.uv.verify()


def _set_edit_mesh_hidden(bm, hidden=False):
    """Set element hide flags without changing topology or UV data."""
    for vertex in bm.verts:
        vertex.hide = bool(hidden)
    for edge in bm.edges:
        edge.hide = bool(hidden)
    for face in bm.faces:
        face.hide = bool(hidden)


def _restore_edit_mesh_hidden(bm, snapshot):
    """Restore element visibility captured before entering Edit Mode."""
    for vertex, state in zip(
            bm.verts, snapshot.get('vertex_hidden', ())):
        vertex.hide = bool(state)
    for edge, state in zip(
            bm.edges, snapshot.get('edge_hidden', ())):
        edge.hide = bool(state)
    for face, state in zip(
            bm.faces, snapshot.get('face_hidden', ())):
        face.hide = bool(state)


def _uv_at_vertex(face, vertex, uv_layer):
    for loop in face.loops:
        if loop.vert == vertex:
            return loop[uv_layer].uv
    raise RuntimeError("Face does not contain edge vertex")


def _derive_seams_from_uv(
        bm, uv_layer, locked_seams, forced_seams=None, preserve_boundaries=False):
    forced_seams = set(forced_seams or ())
    for edge in bm.edges:
        if edge.index in locked_seams or edge.index in forced_seams:
            edge.seam = True
            continue
        if len(edge.link_faces) != 2:
            # Boundary edges are real chart boundaries even though there is no
            # pair of UV loops to compare.  Legacy mode keeps the historical
            # flag behavior; hard-surface mode records them explicitly.
            edge.seam = bool(preserve_boundaries)
            continue
        face_a, face_b = edge.link_faces
        discontinuous = False
        for vertex in edge.verts:
            uv_a = _uv_at_vertex(face_a, vertex, uv_layer)
            uv_b = _uv_at_vertex(face_b, vertex, uv_layer)
            if (uv_a - uv_b).length_squared > 1e-12:
                discontinuous = True
                break
        edge.seam = discontinuous


def _charts(bm):
    chart_ids = [-1] * len(bm.faces)
    charts = []
    for face in bm.faces:
        if chart_ids[face.index] >= 0:
            continue
        chart_index = len(charts)
        pending = [face]
        chart = []
        chart_ids[face.index] = chart_index
        while pending:
            current = pending.pop()
            chart.append(current)
            for edge in current.edges:
                if edge.seam:
                    continue
                for neighbor in edge.link_faces:
                    if chart_ids[neighbor.index] < 0:
                        chart_ids[neighbor.index] = chart_index
                        pending.append(neighbor)
        charts.append(chart)
    return chart_ids, charts


def _uv_charts(bm, uv_layer):
    """Build charts from actual UV continuity, independent of seam flags."""
    chart_ids = [-1] * len(bm.faces)
    charts = []
    for face in bm.faces:
        if chart_ids[face.index] >= 0:
            continue
        chart_index = len(charts)
        chart_ids[face.index] = chart_index
        pending = [face]
        chart = []
        while pending:
            current = pending.pop()
            chart.append(current)
            for edge in current.edges:
                for neighbor in edge.link_faces:
                    if neighbor == current or chart_ids[neighbor.index] >= 0:
                        continue
                    continuous = all(
                        (_uv_at_vertex(current, vertex, uv_layer)
                         - _uv_at_vertex(neighbor, vertex, uv_layer)).length_squared
                        <= 1.0e-12
                        for vertex in edge.verts
                    )
                    if continuous:
                        chart_ids[neighbor.index] = chart_index
                        pending.append(neighbor)
        charts.append(chart)
    return chart_ids, charts


def _chart_area(chart):
    return sum(face.calc_area() for face in chart)


def _compute_face_detail(bm):
    """Estimate local signal/detail complexity from weighted normal variation."""
    values = [0.0] * len(bm.faces)
    bm.faces.index_update()
    for face in bm.faces:
        total_length = 0.0
        variation = 0.0
        for edge in face.edges:
            length = max(edge.calc_length(), 1e-12)
            neighbors = [neighbor for neighbor in edge.link_faces if neighbor != face]
            if not neighbors:
                continue
            angle = edge.calc_face_angle(0.0)
            variation += angle * length
            total_length += length
        if total_length > 1e-12:
            values[face.index] = min(variation / total_length / math.pi, 1.0)
    maximum = max(values, default=0.0)
    if maximum > 1e-12:
        values = [value / maximum for value in values]
    return values


def _boundary_alignment(boundary):
    directions = []
    for edge in boundary:
        direction = edge.verts[1].co - edge.verts[0].co
        if direction.length_squared > 1e-12:
            directions.append(direction.normalized())
    if len(directions) < 2:
        return 0.0
    reference = directions[0]
    return sum(abs(reference.dot(direction)) for direction in directions[1:]) / (len(directions) - 1)


def _developable_band_bonus(chart_left, chart_right, boundary, settings):
    if not settings.developable_enabled:
        return 0.0
    total_length = sum(max(edge.calc_length(), 1e-12) for edge in boundary)
    if total_length <= 1e-12:
        return 0.0
    average_angle = sum(
        edge.calc_face_angle(0.0) * max(edge.calc_length(), 1e-12)
        for edge in boundary
    ) / total_length
    if average_angle > settings.developable_angle:
        return 0.0
    alignment = _boundary_alignment(boundary)
    if alignment < 0.72:
        return 0.0
    combined = chart_left + chart_right
    normal_sum = sum((face.normal for face in combined), Vector((0.0, 0.0, 0.0)))
    if normal_sum.length_squared <= 1e-12:
        return 0.0
    average_normal = normal_sum.normalized()
    spread = sum(
        face.normal.angle(average_normal) * max(face.calc_area(), 1e-12)
        for face in combined
    ) / max(sum(face.calc_area() for face in combined), 1e-12)
    # A long, directionally coherent band with moderate normal spread is
    # characteristic of a cylinder, cone, or bevel strip.
    spread_factor = max(0.0, 1.0 - spread / math.pi)
    angle_factor = max(0.0, 1.0 - average_angle / max(settings.developable_angle, 1e-8))
    return settings.developable_bonus * alignment * spread_factor * angle_factor


def _boundary_seam_cost(boundary, visibility, settings):
    """Estimate how objectionable it is to leave this boundary as a seam."""
    total_length = sum(max(edge.calc_length(), 1e-12) for edge in boundary)
    if total_length <= 1e-12:
        return 0.0
    cost = 0.0
    for edge in boundary:
        length = max(edge.calc_length(), 1e-12)
        faces = list(edge.link_faces)
        face_visibility = max(
            (visibility[face.index] for face in faces if face.index < len(visibility)),
            default=0.0,
        )
        edge_cost = face_visibility * settings.seam_visibility_weight
        if not edge.smooth:
            edge_cost -= settings.seam_hard_edge_bonus
        if len(faces) == 2 and not edge.is_convex:
            edge_cost -= settings.seam_concave_bonus
        cost += edge_cost * length
    return cost / total_length


def _is_disk(faces):
    """Check connected disk topology, including a single boundary loop.

    Euler characteristic alone accepts disconnected patches and some
    multi-boundary/non-manifold configurations.  Merge candidates must be a
    connected orientable disk so an unwrap failure cannot silently weld a hole
    or a second shell into a chart.
    """
    faces = list(faces)
    if not faces:
        return False
    selected = {face.index: face for face in faces}
    pending = [faces[0]]
    visited = {faces[0].index}
    while pending:
        face = pending.pop()
        for edge in face.edges:
            linked = [neighbor for neighbor in edge.link_faces if neighbor.index in selected]
            if len(linked) > 2:
                return False
            for neighbor in linked:
                if neighbor.index not in visited:
                    visited.add(neighbor.index)
                    pending.append(neighbor)
    if len(visited) != len(selected):
        return False
    vertices = {vertex.index for face in faces for vertex in face.verts}
    edges = {edge.index: edge for face in faces for edge in face.edges}
    boundary = {
        index: edge for index, edge in edges.items()
        if sum(1 for linked in edge.link_faces if linked.index in selected) == 1
    }
    if not boundary:
        return False
    boundary_degree = {}
    for edge in boundary.values():
        for vertex in edge.verts:
            boundary_degree[vertex.index] = boundary_degree.get(vertex.index, 0) + 1
    if any(value != 2 for value in boundary_degree.values()):
        return False
    pending_edges = [next(iter(boundary.values()))]
    boundary_seen = {pending_edges[0].index}
    while pending_edges:
        edge = pending_edges.pop()
        edge_vertices = {vertex.index for vertex in edge.verts}
        for other in boundary.values():
            if other.index in boundary_seen:
                continue
            if edge_vertices.intersection(vertex.index for vertex in other.verts):
                boundary_seen.add(other.index)
                pending_edges.append(other)
    if len(boundary_seen) != len(boundary):
        return False
    return len(vertices) - len(edges) + len(faces) == 1


def _triangle_data(faces, uv_layer, bm=None):
    faces = list(faces)
    if bm is not None:
        selected = {face.index for face in faces}
        triangles = []
        for tri_loops in bm.calc_loop_triangles():
            if not tri_loops:
                continue
            face = tri_loops[0].face
            if face.index not in selected:
                continue
            points = tuple(loop.vert.co.copy() for loop in tri_loops)
            uvs = tuple(loop[uv_layer].uv.copy() for loop in tri_loops)
            triangles.append((face.index, points, uvs))
        return triangles

    triangles = []
    for face in faces:
        loops = list(face.loops)
        if len(loops) < 3:
            continue
        coordinates = [loop.vert.co.copy() for loop in loops]
        tessellated = tessellate_polygon([coordinates])
        if not tessellated:
            tessellated = [
                (0, index, index + 1)
                for index in range(1, len(loops) - 1)
            ]
        for triangle in tessellated:
            if isinstance(triangle[0], int):
                indices = triangle
            else:
                indices = tuple(min(
                    range(len(coordinates)),
                    key=lambda index: (coordinates[index] - point).length_squared,
                ) for point in triangle)
            tri_loops = tuple(loops[index] for index in indices)
            points = tuple(loop.vert.co.copy() for loop in tri_loops)
            uvs = tuple(loop[uv_layer].uv.copy() for loop in tri_loops)
            triangles.append((face.index, points, uvs))
    return triangles


def _triangle_stretch(points, uvs):
    p0, p1, p2 = points
    e1 = p1 - p0
    e2 = p2 - p0
    x = e1.length
    if x <= 1e-12:
        return math.inf, 0.0, 0.0
    axis = e1 / x
    sx = e2.dot(axis)
    sy_squared = max(e2.length_squared - sx * sx, 0.0)
    sy = math.sqrt(sy_squared)
    if sy <= 1e-12:
        return math.inf, 0.0, 0.0

    du1 = uvs[1] - uvs[0]
    du2 = uvs[2] - uvs[0]
    j00 = du1.x / x
    j01 = (du2.x - du1.x * sx / x) / sy
    j10 = du1.y / x
    j11 = (du2.y - du1.y * sx / x) / sy
    det = j00 * j11 - j01 * j10

    a = j00 * j00 + j10 * j10
    b = j00 * j01 + j10 * j11
    d = j01 * j01 + j11 * j11
    trace = a + d
    root = math.sqrt(max((a - d) * (a - d) + 4.0 * b * b, 0.0))
    lambda_max = max((trace + root) * 0.5, 0.0)
    lambda_min = max((trace - root) * 0.5, 0.0)
    if lambda_min <= 1e-18:
        stretch = math.inf
    else:
        stretch = math.sqrt(lambda_max / lambda_min)
    area = e1.cross(e2).length * 0.5
    return stretch, area, det


def _weighted_percentile(values, percentile):
    if not values:
        return math.inf
    ordered = sorted(values, key=lambda item: item[0])
    total = sum(weight for _, weight in ordered)
    if total <= 1e-18:
        return math.inf
    target = total * percentile
    accumulated = 0.0
    for value, weight in ordered:
        accumulated += weight
        if accumulated >= target:
            return value
    return ordered[-1][0]


def _measure_distortion(triangles):
    values = []
    maximum = 1.0
    has_positive = False
    has_negative = False
    degenerate = False
    for _, points, uvs in triangles:
        stretch, area, determinant = _triangle_stretch(points, uvs)
        values.append((stretch, max(area, 1e-18)))
        maximum = max(maximum, stretch)
        if determinant > 1e-12:
            has_positive = True
        elif determinant < -1e-12:
            has_negative = True
        else:
            degenerate = True
    invalid_winding = degenerate or has_negative or not has_positive
    return _weighted_percentile(values, 0.95), maximum, invalid_winding


def _positive_triangle_overlap(uv_a, uv_b, epsilon=1e-7):
    for triangle in (uv_a, uv_b):
        for index in range(3):
            edge = triangle[(index + 1) % 3] - triangle[index]
            axis = Vector((-edge.y, edge.x))
            if axis.length_squared <= epsilon * epsilon:
                continue
            values_a = [point.dot(axis) for point in uv_a]
            values_b = [point.dot(axis) for point in uv_b]
            overlap = min(max(values_a), max(values_b)) - max(min(values_a), min(values_b))
            if overlap <= epsilon * axis.length:
                return False
    return True


def _has_overlap(triangles, ignore_same_face=True):
    epsilon = 1e-7
    records = []
    for face_index, _, uvs in triangles:
        minimum_x = min(uv.x for uv in uvs)
        maximum_x = max(uv.x for uv in uvs)
        minimum_y = min(uv.y for uv in uvs)
        maximum_y = max(uv.y for uv in uvs)
        records.append((minimum_x, maximum_x, minimum_y, maximum_y, face_index, uvs))
    records.sort(key=lambda item: item[0])
    active = []
    for record in records:
        minimum_x, maximum_x, minimum_y, maximum_y, face_index, uvs = record
        active = [item for item in active if item[1] > minimum_x + epsilon]
        for other in active:
            if ignore_same_face and face_index == other[4]:
                continue
            if min(maximum_y, other[3]) - max(minimum_y, other[2]) <= epsilon:
                continue
            if _positive_triangle_overlap(uvs, other[5]):
                return True
        active.append(record)
    return False


def _triangle_orientation(points, uvs):
    edge_1 = points[1] - points[0]
    edge_2 = points[2] - points[0]
    edge_3 = points[2] - points[1]
    geometry_scale = max(
        edge_1.length_squared,
        edge_2.length_squared,
        edge_3.length_squared,
        1.0e-30,
    )
    geometry_cross = edge_1.cross(edge_2).length
    if geometry_cross <= max(geometry_scale * 1.0e-12, 1.0e-24):
        return 'source_degenerate'

    uv_edge_1 = uvs[1] - uvs[0]
    uv_edge_2 = uvs[2] - uvs[0]
    uv_edge_3 = uvs[2] - uvs[1]
    uv_scale = max(
        uv_edge_1.length_squared,
        uv_edge_2.length_squared,
        uv_edge_3.length_squared,
        1.0e-30,
    )
    signed_uv_area_2 = (
        uv_edge_1.x * uv_edge_2.y - uv_edge_1.y * uv_edge_2.x)
    if abs(signed_uv_area_2) <= max(uv_scale * 1.0e-12, 1.0e-24):
        return 'uv_degenerate'
    return 'positive' if signed_uv_area_2 > 0.0 else 'negative'


def _winding_counts(triangles):
    counts = {
        'positive': 0,
        'negative': 0,
        'degenerate': 0,
        'source_degenerate': 0,
        'uv_degenerate': 0,
    }
    for _, points, uvs in triangles:
        orientation = _triangle_orientation(points, uvs)
        if orientation in {'positive', 'negative'}:
            counts[orientation] += 1
        else:
            counts['degenerate'] += 1
            counts[orientation] += 1
    return counts


def _classify_problem_charts(charts, uv_layer, bm=None):
    """Return charts needing re-projection and consistently mirrored charts."""
    triangles_by_face = defaultdict(list)
    if bm is not None:
        all_faces = [face for chart in charts for face in chart]
        for triangle in _triangle_data(all_faces, uv_layer, bm=bm):
            triangles_by_face[triangle[0]].append(triangle)
    problem = []
    mirrored = []
    for chart in charts:
        if bm is None:
            triangles = _triangle_data(chart, uv_layer)
        else:
            triangles = [
                triangle
                for face in chart
                for triangle in triangles_by_face.get(face.index, ())
            ]
        finite = all(
            math.isfinite(value)
            for _, _, uvs in triangles
            for uv in uvs for value in (uv.x, uv.y)
        )
        counts = _winding_counts(triangles)
        positive = counts['positive']
        negative = counts['negative']
        invalid = (
            not triangles
            or not finite
            or counts['degenerate'] > 0
            or (positive > 0 and negative > 0)
            or _has_overlap(triangles, ignore_same_face=False)
        )
        if invalid:
            problem.append(chart)
        elif negative > 0 and positive == 0:
            mirrored.append(chart)
    return problem, mirrored


def _mirror_charts_u(charts, uv_layer):
    for chart in charts:
        loops = [loop for face in chart for loop in face.loops]
        if not loops:
            continue
        minimum_u = min(loop[uv_layer].uv.x for loop in loops)
        maximum_u = max(loop[uv_layer].uv.x for loop in loops)
        center_u = (minimum_u + maximum_u) * 0.5
        for loop in loops:
            loop[uv_layer].uv.x = 2.0 * center_u - loop[uv_layer].uv.x


def _audit_unique_layout(bm, uv_layer, epsilon=1.0e-6):
    points = [loop[uv_layer].uv for face in bm.faces for loop in face.loops]
    finite = bool(points) and all(
        math.isfinite(point.x) and math.isfinite(point.y) for point in points
    )
    triangles = _triangle_data(list(bm.faces), uv_layer, bm=bm) if finite else []
    counts = _winding_counts(triangles)
    inside_tile = finite and all(
        -epsilon <= value <= 1.0 + epsilon
        for point in points for value in (point.x, point.y)
    )
    return {
        'triangles': len(triangles),
        'positive': counts['positive'],
        'negative': counts['negative'],
        'degenerate': counts['degenerate'],
        'source_degenerate': counts['source_degenerate'],
        'uv_degenerate': counts['uv_degenerate'],
        'finite': finite,
        'inside_tile': inside_tile,
        'overlap': finite and (
            _has_overlap(triangles, ignore_same_face=False)
            if triangles else False
        ),
    }


def _unique_layout_error(audit):
    if not audit['finite']:
        return "Unique UV quality gate: non-finite coordinate"
    if not audit['inside_tile']:
        return "Unique UV quality gate: coordinates outside the 0-1 tile"
    if audit['source_degenerate']:
        return (
            "Unique UV quality gate: source mesh has {} degenerate triangles; "
            "clean the geometry before unwrapping"
        ).format(audit['source_degenerate'])
    if audit['uv_degenerate']:
        return "Unique UV quality gate: {} UV-degenerate triangles".format(
            audit['uv_degenerate'])
    if audit['negative']:
        return "Unique UV quality gate: {} flipped triangles".format(
            audit['negative'])
    if not audit['positive']:
        return "Unique UV quality gate: no positive-area triangles"
    if audit['overlap']:
        return "Unique UV quality gate: positive-area overlap"
    return None


def _save_uv(faces, uv_layer):
    return {
        face.index: [loop[uv_layer].uv.copy() for loop in face.loops]
        for face in faces
    }


def _restore_uv(faces, uv_layer, saved):
    for face in faces:
        for loop, uv in zip(face.loops, saved[face.index]):
            loop[uv_layer].uv = uv


def _candidate_groups(
        bm, chart_ids, charts, locked_seams, blocked, visibility, settings,
        probe_evidence=None, edge_policy=None, face_classes=None,
        hard_surface_mode=False):
    edge_policy = edge_policy or {}
    face_classes = face_classes or {}
    groups = defaultdict(list)
    for edge in bm.edges:
        if not edge.seam or len(edge.link_faces) != 2 or edge.index in locked_seams:
            continue
        policy = edge_policy.get(edge.index, 'NEUTRAL')
        if policy in {'LOCKED_CUT', 'FORCE_CUT'}:
            continue
        face_a, face_b = edge.link_faces
        chart_a = chart_ids[face_a.index]
        chart_b = chart_ids[face_b.index]
        if chart_a == chart_b:
            continue
        if settings.respect_materials and face_a.material_index != face_b.material_index:
            continue
        if settings.respect_sharp and not edge.smooth:
            continue
        if hard_surface_mode:
            class_a = face_classes.get(face_a.index, 'GENERAL')
            class_b = face_classes.get(face_b.index, 'GENERAL')
            if not hard_surface.can_merge_classes(class_a, class_b):
                continue
        groups[tuple(sorted((chart_a, chart_b)))].append(edge)

    total_area = sum(_chart_area(chart) for chart in charts)
    candidates = []
    for (chart_a, chart_b), boundary in groups.items():
        signature = frozenset(edge.index for edge in boundary)
        if signature in blocked:
            continue
        chart_left = charts[chart_a]
        chart_right = charts[chart_b]
        lengths = [max(edge.calc_length(), 1e-12) for edge in boundary]
        total_length = sum(lengths)
        average_angle = sum(
            edge.calc_face_angle(0.0) * length for edge, length in zip(boundary, lengths)
        ) / total_length
        area_left = _chart_area(chart_left)
        area_right = _chart_area(chart_right)
        if hard_surface_mode:
            small = (
                min(len(chart_left), len(chart_right)) <= settings.small_island_faces
                and min(area_left, area_right) <= total_area * settings.small_island_area_ratio
            )
        else:
            small = (
                min(len(chart_left), len(chart_right)) <= settings.small_island_faces
                or min(area_left, area_right) <= total_area * settings.small_island_area_ratio
            )
        if average_angle > settings.merge_angle and not (small and not hard_surface_mode):
            continue
        seam_cost = _boundary_seam_cost(boundary, visibility, settings)
        score = average_angle / max(settings.merge_angle, 1e-8)
        # Removing a seam is most valuable where that seam would be visible.
        score -= seam_cost * 0.25
        score -= _developable_band_bonus(
            chart_left, chart_right, boundary, settings)
        if small and hard_surface_mode:
            # Small hardware gets only a modest ordering preference.  It must
            # still satisfy the normal angle gate and may never cross a hard
            # policy edge merely because it has few faces.
            score -= 0.15
        elif small:
            score -= 0.9
        score -= min(total_length / max(math.sqrt(total_area), 1e-8), 1.0) * 0.1
        probe = probe_analysis.summarize_boundary(
            boundary,
            probe_evidence,
            min_confidence=settings.probe_min_confidence,
            reject_flipped=settings.probe_reject_flipped,
        )
        if (
            settings.probe_enabled
            and probe["supported"]
            and not probe["hard_reject"]
        ):
            score -= (
                settings.probe_merge_bonus
                * probe["score"]
                * max(probe["confidence"], 0.0)
            )
        elif settings.probe_enabled and probe["hard_reject"]:
            # Keep rejected candidates in reports, but sort them after viable
            # candidates so an optimizer pass can explicitly count the reason.
            score += 1000.0
        candidates.append((score, chart_a, chart_b, boundary, signature, probe))
    candidates.sort(key=lambda item: item[0])
    return candidates


def build_probe_candidate_report(obj, settings):
    """Report current UV boundary candidates and their probe evidence.

    This is intentionally read-only. It does not run Smart UV, unwrap, or
    change the object's seams, UVs, selection, or mode.
    """
    evidence = probe_analysis.load_stored_evidence(obj)
    bm = bmesh.new()
    try:
        bm.from_mesh(obj.data)
        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.active
        if uv_layer is None:
            raise ValueError("Active mesh has no UV layer")
        _derive_seams_from_uv(bm, uv_layer, set())
        chart_ids, charts = _charts(bm)
        visibility = effective_face_visibility(obj.data, default=1.0)
        candidates = _candidate_groups(
            bm, chart_ids, charts, set(), set(), visibility, settings, evidence)
        report = {
            "schema": probe_analysis.SCHEMA,
            "object": obj.name,
            "charts": len(charts),
            "evidence_edges": len(evidence["edges"]) if evidence else 0,
            "candidates": [],
        }
        for score, chart_a, chart_b, boundary, signature, probe in candidates:
            report["candidates"].append({
                "chart_a": chart_a,
                "chart_b": chart_b,
                "score": round(float(score), 6),
                "boundary_edges": sorted(int(value) for value in signature),
                "boundary_vertices": [
                    sorted(int(vertex.index) for vertex in edge.verts)
                    for edge in boundary
                ],
                "probe": probe,
            })
        return report
    finally:
        bm.free()


def _try_merge(
        obj, bm, uv_layer, faces, boundary, settings, reject_overlap=True):
    if not _is_disk(faces):
        return False, 'TOPOLOGY'

    saved_uv = _save_uv(faces, uv_layer)
    old_seams = [edge.seam for edge in boundary]
    accepted = False
    for edge in boundary:
        edge.seam = False
    _set_uv_selection(bm, uv_layer, (face.index for face in faces))
    bmesh.update_edit_mesh(obj.data, loop_triangles=False, destructive=False)

    try:
        result = _call_uv_operator(
            bpy.ops.uv.unwrap,
            _operator_name='unwrap',
            method='ANGLE_BASED',
            fill_holes=True,
            correct_aspect=True,
            use_subsurf_data=False,
            margin=settings.island_margin,
        )
        if 'FINISHED' not in result:
            return False, 'STRETCH'

        triangles = _triangle_data(faces, uv_layer)
        p95, maximum, flipped = _measure_distortion(triangles)
        if flipped or p95 > settings.max_p95_stretch or maximum > settings.max_stretch:
            return False, 'STRETCH'
        if reject_overlap and _has_overlap(triangles):
            return False, 'OVERLAP'
        accepted = True
        return True, 'ACCEPT'
    except (RuntimeError, ValueError, TypeError):
        return False, 'STRETCH'
    finally:
        # A failed operator can still return FINISHED in some Blender builds;
        # restore the candidate whenever the caller sees a rejection.
        # The success path is detected by checking the local return value.
        if not accepted:
            _restore_uv(faces, uv_layer, saved_uv)
            for edge, old_value in zip(boundary, old_seams):
                edge.seam = old_value


def _scale_charts_by_visibility(
        bm, uv_layer, charts, visibility, detail_values, settings,
        hard_surface_mode=False):
    for chart in charts:
        all_hidden = all(
            face.index < len(visibility) and visibility[face.index] <= 0.0
            for face in chart
        )
        if all_hidden:
            # Legacy keeps red charts tiny and collapses them later.  A unique
            # hard-surface layout uses a non-zero floor for automatic zero-hit
            # faces; only explicit Hidden overrides are collapsed.
            scale = 0.25 if hard_surface_mode else _LOW_VISIBILITY_SCALE
        else:
            # A chart containing any visible face must not be reduced merely
            # because a neighboring face is hidden. Hidden faces are split
            # from mixed charts during the final origin-collapse pass.
            importance = max((visibility[face.index] for face in chart), default=0.0)
            normalized = min(importance / max(settings.visibility_high, 1e-8), 1.0)
            scale = (
                _LOW_VISIBILITY_SCALE
                + (1.0 - _LOW_VISIBILITY_SCALE) * normalized
            )
            detail = sum(
                detail_values[face.index] * max(face.calc_area(), 1e-12)
                for face in chart
            ) / max(_chart_area(chart), 1e-12)
            scale *= 1.0 + settings.detail_strength * detail
            scale = min(scale, settings.detail_scale_cap)
        if scale >= 0.999999:
            continue
        loops = [loop for face in chart for loop in face.loops]
        if not loops:
            continue
        center = sum((loop[uv_layer].uv for loop in loops), Vector((0.0, 0.0))) / len(loops)
        for loop in loops:
            loop[uv_layer].uv = center + (loop[uv_layer].uv - center) * scale


def _collapse_hidden_faces_to_origin(
        bm, uv_layer, visibility, overrides=None, explicit_only=False):
    """Collapse hidden faces, optionally restricting this to explicit overrides."""
    origin = Vector((0.0, 0.0))
    for face in bm.faces:
        if face.index >= len(visibility) or visibility[face.index] > 0.0:
            continue
        if explicit_only and (
                overrides is None or face.index >= len(overrides)
                or overrides[face.index] >= 0):
            continue
        for loop in face.loops:
            loop[uv_layer].uv = origin


def _normalize_uv_to_tile(bm, uv_layer, margin):
    """Fit an active unique UV layout into one tile after packing.

    Blender 3.3's pack operator has no ``scale`` keyword, and Blender 5.2's
    default can likewise preserve large pre-pack coordinates.  A deterministic
    final affine fit keeps the shared path inside the requested tile without
    changing island topology or relative texel density.
    """
    points = [loop[uv_layer].uv for face in bm.faces for loop in face.loops]
    if not points:
        return False
    minimum_x = min(point.x for point in points)
    maximum_x = max(point.x for point in points)
    minimum_y = min(point.y for point in points)
    maximum_y = max(point.y for point in points)
    width = maximum_x - minimum_x
    height = maximum_y - minimum_y
    usable = max(1.0 - 2.0 * max(float(margin), 0.0), 1.0e-6)
    if width <= 1.0e-12 and height <= 1.0e-12:
        return False
    scale = usable / max(width, height, 1.0e-12)
    offset = Vector((
        max(float(margin), 0.0) - minimum_x * scale,
        max(float(margin), 0.0) - minimum_y * scale,
    ))
    for point in points:
        point *= scale
        point += offset
    return True


def optimize_active_object(context, obj, settings):
    mesh = obj.data
    mesh.update()
    if not mesh.polygons:
        raise ValueError("Active mesh contains no faces")
    snapshot = _snapshot_mesh_uv_state(mesh)
    visibility = effective_face_visibility(mesh, default=1.0)
    overrides = read_face_int(mesh)
    probe_evidence = probe_analysis.load_stored_evidence(obj)
    original_seams = {
        edge.index for edge in mesh.edges if edge.use_seam
    } if settings.preserve_seams else set()
    uv_usage = _resolve_uv_usage(obj, settings)
    initial_uv_mode = _resolve_initial_uv_mode(settings, original_seams, uv_usage)
    hard_surface_mode = initial_uv_mode in {'HARD_SURFACE', 'MARKED_SEAMS'}
    edge_policy = {}
    face_classes = {}
    forced_cuts = set()
    protected_cuts = set()
    detail_values = []

    if initial_uv_mode == 'PRESERVE_LAYOUT':
        island_count, detail_values = _inspect_existing_layout(mesh)
        try:
            write_face_float(mesh, detail_values, name='vuv_detail_score')
        except Exception:
            _restore_face_float_attribute(
                mesh, 'vuv_detail_score', snapshot.get('detail_score'))
            raise
        return OptimizeResult(
            initial_islands=island_count,
            final_islands=island_count,
            merge_tests=0,
            accepted_merges=0,
            rejected_stretch=0,
            rejected_overlap=0,
            rejected_topology=0,
            detail_values=detail_values,
            initial_uv_mode=initial_uv_mode,
            uv_usage=uv_usage,
        )

    try:
        bpy.ops.object.mode_set(mode='EDIT')
        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.index_update()
        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        _set_edit_mesh_hidden(bm, hidden=False)
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
        bpy.ops.mesh.select_all(action='SELECT')

        bm = bmesh.from_edit_mesh(mesh)
        bm.faces.index_update()
        bm.faces.ensure_lookup_table()
        bm.edges.ensure_lookup_table()
        bm.verts.ensure_lookup_table()
        uv_layer = bm.loops.layers.uv.verify()

        if hard_surface_mode:
            if not settings.preserve_seams:
                for edge in bm.edges:
                    edge.seam = False
            constraints = hard_surface.classify_edge_constraints(
                bm,
                settings,
                mode=initial_uv_mode,
                original_seams=original_seams,
            )
            edge_policy = dict(getattr(constraints, 'edge_policy', {}))
            face_classes = dict(getattr(constraints, 'face_classes', {}))
            forced_cuts = set(getattr(constraints, 'forced_cuts', set()))
            protected_cuts = set(getattr(constraints, 'protected_cuts', set()))
            locked_cuts = set(getattr(constraints, 'locked_cuts', original_seams))
            for edge in bm.edges:
                edge.seam = edge.index in locked_cuts or edge.index in forced_cuts
            bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)

            unwrap_result = _call_uv_operator(
                bpy.ops.uv.unwrap,
                _operator_name='unwrap',
                method='ANGLE_BASED',
                fill_holes=True,
                correct_aspect=True,
                use_subsurf_data=False,
                margin=settings.island_margin,
            )
            if 'FINISHED' not in unwrap_result:
                raise RuntimeError("Hard-surface UV unwrap did not finish")

            # Re-fetch the edit BMesh after an operator call; Blender may
            # invalidate loop wrappers while rebuilding the UV layer.
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.index_update()
            bm.faces.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.verify()
            # Record the unwrap's real chart boundaries before optional
            # geometric cleanup.  A classifier region is not allowed to split
            # an already continuous chart merely because its normals form a
            # smaller panel or band.
            _derive_seams_from_uv(
                bm,
                uv_layer,
                locked_cuts,
                forced_cuts,
                preserve_boundaries=True,
            )
            regions = hard_surface.build_region_seed_records(bm, constraints)
            for record in regions:
                region = list(record.faces)
                classes = {face_classes.get(face.index, 'GENERAL') for face in region}
                chart_bounded = all(
                    bm.edges[index].seam
                    for index in record.boundary_edges
                    if 0 <= index < len(bm.edges)
                )
                planar_classes = {
                    'PLANAR_PANEL', 'PANEL', 'RADIAL_CAP', 'CAP'
                }
                if chart_bounded and classes and classes <= planar_classes:
                    saved_region_uv = _save_uv(region, uv_layer)
                    if hard_surface.project_planar_region(region, uv_layer):
                        triangles = _triangle_data(region, uv_layer)
                        p95, maximum, flipped = _measure_distortion(triangles)
                        if (
                            flipped
                            or p95 > settings.max_p95_stretch
                            or maximum > settings.max_stretch
                            or _has_overlap(triangles)
                        ):
                            _restore_uv(region, uv_layer, saved_region_uv)
                band_classes = {
                    'BEVEL_STRIP', 'BEVEL', 'QUAD_STRIP', 'STRIP',
                    'CYLINDER_SIDE', 'CYLINDER'
                }
                if chart_bounded and classes and classes <= band_classes:
                    hard_surface.align_island_cardinal(region, uv_layer)
            _derive_seams_from_uv(
                bm,
                uv_layer,
                locked_cuts,
                forced_cuts,
                preserve_boundaries=True,
            )
        else:
            smart_result = _call_uv_operator(
                bpy.ops.uv.smart_project,
                _operator_name='smart_project',
                angle_limit=settings.smart_angle,
                island_margin=settings.island_margin,
                area_weight=0.0,
                correct_aspect=True,
                scale_to_bounds=False,
            )
            if 'FINISHED' not in smart_result:
                raise RuntimeError("Smart UV Project did not finish")
            bm = bmesh.from_edit_mesh(mesh)
            bm.faces.index_update()
            bm.faces.ensure_lookup_table()
            bm.edges.ensure_lookup_table()
            bm.verts.ensure_lookup_table()
            uv_layer = bm.loops.layers.uv.verify()
            _derive_seams_from_uv(bm, uv_layer, original_seams)

        detail_values = _compute_face_detail(bm)
        bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)

        _, initial_charts = _charts(bm)
        initial_count = len(initial_charts)
        blocked = set()
        merge_tests = 0
        accepted = 0
        rejected_stretch = 0
        rejected_overlap = 0
        rejected_topology = 0
        rejected_probe = 0
        probe_guided_merges = 0
        repaired_charts = 0
        mirrored_chart_count = 0
        safe_pack_retry = False
        reject_overlap = bool(settings.reject_overlap and uv_usage == 'UNIQUE')

        while merge_tests < settings.max_merge_tests:
            chart_ids, charts = _charts(bm)
            candidates = _candidate_groups(
                bm, chart_ids, charts, original_seams, blocked, visibility,
                settings, probe_evidence, edge_policy, face_classes,
                hard_surface_mode)
            if not candidates:
                break

            merged_this_round = False
            for _, chart_a, chart_b, boundary, signature, probe in candidates:
                if merge_tests >= settings.max_merge_tests:
                    break
                merge_tests += 1
                if settings.probe_enabled and probe["hard_reject"]:
                    rejected_probe += 1
                    blocked.add(signature)
                    continue
                faces = charts[chart_a] + charts[chart_b]
                accepted_merge, reason = _try_merge(
                    obj, bm, uv_layer, faces, boundary, settings,
                    reject_overlap=reject_overlap)
                if accepted_merge:
                    accepted += 1
                    if (
                        settings.probe_enabled
                        and probe["supported"]
                        and probe["score"] >= 0.5
                    ):
                        probe_guided_merges += 1
                    merged_this_round = True
                    bmesh.update_edit_mesh(mesh, loop_triangles=False, destructive=False)
                    break
                blocked.add(signature)
                if reason == 'OVERLAP':
                    rejected_overlap += 1
                elif reason == 'TOPOLOGY':
                    rejected_topology += 1
                else:
                    rejected_stretch += 1
            if not merged_this_round:
                break

        _, final_charts = _uv_charts(bm, uv_layer)
        if uv_usage == 'UNIQUE':
            problem_charts, mirrored_charts = _classify_problem_charts(
                final_charts, uv_layer, bm=bm)
            mirrored_chart_count += len(mirrored_charts)
            _mirror_charts_u(mirrored_charts, uv_layer)
            if problem_charts:
                repaired_charts = len(problem_charts)
                repair_faces = {
                    face.index for chart in problem_charts for face in chart
                }
                _set_uv_selection(bm, uv_layer, repair_faces)
                bmesh.update_edit_mesh(
                    mesh, loop_triangles=False, destructive=False)
                repair_result = _call_uv_operator(
                    bpy.ops.uv.smart_project,
                    _operator_name='smart_project',
                    angle_limit=settings.smart_angle,
                    island_margin=settings.island_margin,
                    area_weight=0.0,
                    correct_aspect=True,
                    scale_to_bounds=False,
                    preserve_seams=True,
                )
                if 'FINISHED' not in repair_result:
                    raise RuntimeError(
                        "Unique UV repair projection did not finish")
                bm, uv_layer = _refresh_edit_bmesh(mesh)
                _derive_seams_from_uv(
                    bm,
                    uv_layer,
                    original_seams,
                    forced_cuts,
                    preserve_boundaries=hard_surface_mode,
                )
                _, final_charts = _uv_charts(bm, uv_layer)
                problem_charts, mirrored_charts = _classify_problem_charts(
                    final_charts, uv_layer, bm=bm)
                mirrored_chart_count += len(mirrored_charts)
                _mirror_charts_u(mirrored_charts, uv_layer)
                if problem_charts:
                    raise RuntimeError(
                        "Unique UV repair left {} folded or degenerate charts".format(
                            len(problem_charts)))

        bm, uv_layer = _select_all_uvs_for_operator(
            mesh, bm, uv_layer)
        scale_result = _call_uv_operator(
            bpy.ops.uv.average_islands_scale,
            _operator_name='average_islands_scale')
        if 'FINISHED' not in scale_result:
            raise RuntimeError("Average Islands Scale did not finish")
        bm, uv_layer = _refresh_edit_bmesh(mesh)
        _, final_charts = _uv_charts(bm, uv_layer)
        _scale_charts_by_visibility(
            bm, uv_layer, final_charts, visibility, detail_values, settings,
            hard_surface_mode=hard_surface_mode)
        if hard_surface_mode and getattr(settings, 'hard_surface_align_cardinal', True):
            for chart in final_charts:
                hard_surface.align_island_cardinal(chart, uv_layer)
        bm, uv_layer = _select_all_uvs_for_operator(
            mesh, bm, uv_layer)
        if hard_surface_mode:
            pack_result = _call_uv_operator(
                bpy.ops.uv.pack_islands,
                _operator_name='pack_islands',
                udim_source='ACTIVE_UDIM',
                rotate=False,
                scale=True,
                merge_overlap=False,
                margin=settings.island_margin,
                margin_method='FRACTION',
                pin=False,
                rotate_method='CARDINAL',
                shape_method='CONCAVE',
            )
        else:
            pack_result = _call_uv_operator(
                bpy.ops.uv.pack_islands,
                _operator_name='pack_islands',
                udim_source='ACTIVE_UDIM',
                rotate=True,
                scale=True,
                merge_overlap=False,
                margin=settings.island_margin,
                margin_method='FRACTION',
                pin=False,
                shape_method='CONCAVE',
            )
        if 'FINISHED' not in pack_result:
            raise RuntimeError("Pack Islands did not finish")
        # UV packing is an edit-mesh operator.  Re-fetch the BMesh before any
        # final seam derivation so a stale wrapper cannot write pre-pack UVs
        # back over the packed coordinates (notably visible on cap/side
        # islands in Blender 3.3 and 5.x).
        bm, uv_layer = _refresh_edit_bmesh(mesh)
        if uv_usage == 'UNIQUE':
            _normalize_uv_to_tile(bm, uv_layer, settings.island_margin)
        if hard_surface_mode and getattr(settings, 'hard_surface_hidden_collapse', False):
            _collapse_hidden_faces_to_origin(
                bm,
                uv_layer,
                visibility,
                overrides=overrides,
                explicit_only=True,
            )
        elif not hard_surface_mode:
            _collapse_hidden_faces_to_origin(bm, uv_layer, visibility)
        _derive_seams_from_uv(
            bm,
            uv_layer,
            original_seams,
            forced_cuts,
            preserve_boundaries=hard_surface_mode,
        )
        _, final_charts = _uv_charts(bm, uv_layer)
        if uv_usage == 'UNIQUE':
            problem_charts, mirrored_charts = _classify_problem_charts(
                final_charts, uv_layer, bm=bm)
            mirrored_chart_count += len(mirrored_charts)
            _mirror_charts_u(mirrored_charts, uv_layer)
            if problem_charts:
                raise RuntimeError(
                    "Unique UV quality gate: {} folded or degenerate charts".format(
                        len(problem_charts)))
            audit = _audit_unique_layout(bm, uv_layer)
            if audit['overlap']:
                safe_pack_retry = True
                # Exact concave packing can still leave numerical or cross-tile
                # collisions on dense imported layouts.  AABB is less compact,
                # but its disjoint rectangles provide a deterministic safety
                # fallback before the transaction is rejected.
                bm, uv_layer = _select_all_uvs_for_operator(
                    mesh, bm, uv_layer)
                retry_result = _call_uv_operator(
                    bpy.ops.uv.pack_islands,
                    _operator_name='pack_islands',
                    udim_source='ACTIVE_UDIM',
                    rotate=True,
                    rotate_method='CARDINAL',
                    scale=True,
                    merge_overlap=False,
                    margin=settings.island_margin,
                    margin_method='FRACTION',
                    pin=False,
                    shape_method='AABB',
                )
                if 'FINISHED' not in retry_result:
                    raise RuntimeError("Safe AABB Pack Islands did not finish")
                bm, uv_layer = _refresh_edit_bmesh(mesh)
                _normalize_uv_to_tile(bm, uv_layer, settings.island_margin)
                _derive_seams_from_uv(
                    bm,
                    uv_layer,
                    original_seams,
                    forced_cuts,
                    preserve_boundaries=hard_surface_mode,
                )
                _, final_charts = _uv_charts(bm, uv_layer)
                problem_charts, mirrored_charts = _classify_problem_charts(
                    final_charts, uv_layer, bm=bm)
                mirrored_chart_count += len(mirrored_charts)
                _mirror_charts_u(mirrored_charts, uv_layer)
                if problem_charts:
                    raise RuntimeError(
                        "Unique UV quality gate: {} invalid charts after safe pack".format(
                            len(problem_charts)))
                audit = _audit_unique_layout(bm, uv_layer)
            quality_error = _unique_layout_error(audit)
            if quality_error is not None:
                raise RuntimeError(quality_error)
        else:
            for loop in (loop for face in bm.faces for loop in face.loops):
                uv = loop[uv_layer].uv
                if not (math.isfinite(uv.x) and math.isfinite(uv.y)):
                    raise RuntimeError(
                        "UV operation produced a non-finite coordinate")
        _restore_edit_mesh_hidden(bm, snapshot)
        bmesh.update_edit_mesh(mesh, loop_triangles=True, destructive=False)
        bpy.ops.object.mode_set(mode='OBJECT')
        _restore_mesh_interaction_state(mesh, snapshot)
        write_face_float(mesh, detail_values, name='vuv_detail_score')

        return OptimizeResult(
            initial_islands=initial_count,
            final_islands=len(final_charts),
            merge_tests=merge_tests,
            accepted_merges=accepted,
            rejected_stretch=rejected_stretch,
            rejected_overlap=rejected_overlap,
            rejected_topology=rejected_topology,
            detail_values=detail_values,
            rejected_probe=rejected_probe,
            probe_guided_merges=probe_guided_merges,
            initial_uv_mode=initial_uv_mode,
            uv_usage=uv_usage,
            forced_cuts=len(forced_cuts),
            protected_cuts=len(protected_cuts),
            repaired_charts=repaired_charts,
            mirrored_charts=mirrored_chart_count,
            safe_pack_retry=safe_pack_retry,
        )
    except Exception:
        # The operator is undoable, but a direct API call or an operator error
        # should also leave the user's original UVs and seams intact.
        try:
            if obj.mode != 'OBJECT':
                bpy.ops.object.mode_set(mode='OBJECT')
        except (RuntimeError, ValueError):
            pass
        _restore_mesh_uv_state(mesh, snapshot)
        raise
